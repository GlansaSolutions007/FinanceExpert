<?= $this->extend('layouts/dashboard_layout'); ?>
<?= $this->section('content')?>
<h1>Agent Report</h1>
<?= $this->endSection()?>