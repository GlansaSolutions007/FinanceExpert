<?= $this->extend('layouts/dashboard_layout'); ?>
<?= $this->section('content')?>
<h1>Staff Details</h1>
<?= $this->endSection()?>