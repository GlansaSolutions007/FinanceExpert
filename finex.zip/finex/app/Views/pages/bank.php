<?= $this->extend('layouts/dashboard_layout'); ?>
<?= $this->section('content')?>
<h1>This is Bank Page</h1>
<?= base_url()?>
<?= $this->endSection()?>