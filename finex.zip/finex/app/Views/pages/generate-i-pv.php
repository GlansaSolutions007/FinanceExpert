<?= $this->extend('layouts/dashboard_layout'); ?>
<?= $this->section('content')?>
<h1>Generate Invoice and Payment Voucher</h1>
<?= $this->endSection()?>