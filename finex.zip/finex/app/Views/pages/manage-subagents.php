<?= $this->extend('layouts/dashboard_layout'); ?>
<?= $this->section('content')?>
<h1>Managing SUb Agents</h1>
<?= $this->endSection()?>