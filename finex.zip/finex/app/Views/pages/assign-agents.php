<?= $this->extend('layouts/dashboard_layout'); ?>
<?= $this->section('content')?>
<h1>Assign Agents to LOS</h1>
<?= $this->endSection()?>