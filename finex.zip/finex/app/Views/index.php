<h3>hety</h3>
<p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iste deserunt, ipsam sed quaerat atque veritatis ipsa dolores aut iusto voluptates possimus porro laborum. Necessitatibus quos tempore animi voluptatem aut esse?</p>

<?= base_url(); ?>