<?php

namespace App\Controllers;



class admin extends BaseController
{
    public function home()
    {   
        $data['pageTitle']='Dashboard';
        return view('pages/index',$data);
    }
    public function bank()
    {   
        $data['pageTitle']='Bank';
        return view('pages/bank',$data);
    }
    public function agent()
    {   
        $data['pageTitle']='Agent Details';
        return view('pages/agent',$data);
    }
    public function staff()
    {   
        $data['pageTitle']='Staff Details';
        return view('pages/staff',$data);
    }
    public function uploadmaster()
    {   
        $data['pageTitle']='Upload Master Sheet';
        return view('pages/upload-master-sheet',$data);
    }
    public function viewmaster()
    {   
        $data['pageTitle']='View Master Sheet';
        return view('pages/view-master',$data);
    }
    public function assignagents()
    {   
        $data['pageTitle']='Assign Agents';
        return view('pages/assign-agents',$data);
    }
    public function subagents()
    {   
        $data['pageTitle']='Manage Sub Agents';
        return view('pages/manage-subagents',$data);
    }
    public function mis()
    {   
        $data['pageTitle']='MIS Calculations';
        return view('pages/mis-calculations',$data);
    }
    public function gipv()
    {   
        $data['pageTitle']='Generate Invoice & Payment voucher';
        return view('pages/generate-i-pv',$data);
    }
    public function empty()
    {   
        $data['pageTitle']='Empty';
        return view('pages/empty',$data);
    }
    public function agentlist()
    {   
        $data['pageTitle']='Agent List';
        return view('pages/agent-list',$data);
    }
    public function agentinvoicereport()
    {   
        $data['pageTitle']='Agent Invoice Report';
        return view('pages/agent-invoice-report',$data);
    }
    public function Agentmasterreport()
    {   
        $data['pageTitle']='Agent Master Report';
        return view('pages/agent-report',$data);
    }
    public function bankmasterreport()
    {   
        $data['pageTitle']='Bank Master Report';
        return view('pages/bank-report',$data);
    }
    public function lossearch()
    {   
        $data['pageTitle']='LOS Search';
        return view('pages/LOS-search',$data);
    }
    public function customersearch()
    {   
        $data['pageTitle']='Customer Search';
        return view('pages/c-name-search',$data);
    }
    public function bankbranch()
    {   
        $data['pageTitle']='Bank Branch Search';
        return view('pages/b-b-search',$data);
    }
    public function gstreport()
    {   
        $data['pageTitle']='GST Report';
        return view('pages/gst-report',$data);
    }
    

    
    
}
