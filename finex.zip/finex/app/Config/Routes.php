<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');
// $routes->get('/admin', 'Home::demo');

$routes->group("admin",function($routes){
    $routes->get('home','admin::home',['as'=>'admin.home']);
    $routes->get('bank','admin::bank',['as'=>'admin.bank']);
    $routes->get('agent','admin::agent',['as'=>'admin.agent']);
    $routes->get('staff','admin::staff',['as'=>'admin.staff']);
    $routes->get('uploadmaster','admin::uploadmaster',['as'=>'admin.uploadmaster']);
    $routes->get('viewmaster','admin::viewmaster',['as'=>'admin.viewmaster']);
    $routes->get('assignagents','admin::assignagents',['as'=>'admin.assignagents']);
    $routes->get('subagents','admin::subagents',['as'=>'admin.subagents']);
    $routes->get('mis','admin::mis',['as'=>'admin.mis']);
    $routes->get('gipv','admin::gipv',['as'=>'admin.gipv']);
    $routes->get('empty','admin::empty',['as'=>'admin.empty']);
    $routes->get('agentlist','admin::agentlist',['as'=>'admin.agentlist']);
    $routes->get('agentinvoicereport','admin::agentinvoicereport',['as'=>'admin.agentinvoicereport']);
    $routes->get('Agentmasterreport','admin::Agentmasterreport',['as'=>'admin.Agentmasterreport']);
    $routes->get('bankmasterreport','admin::bankmasterreport',['as'=>'admin.bankmasterreport']);
    $routes->get('lossearch','admin::lossearch',['as'=>'admin.lossearch']);
    $routes->get('customersearch','admin::customersearch',['as'=>'admin.customersearch']);
    $routes->get('bankbranch','admin::bankbranch',['as'=>'admin.bankbranch']);
    $routes->get('gstreport','admin::gstreport',['as'=>'admin.gstreport']);

    

});
// $routes->get('/', 'admin::home');


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
